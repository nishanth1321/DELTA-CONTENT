<html>
<head>
    <title>Jakarta Maven Web App</title>
</head>
<body>
<h2>Welcome to Jakarta Maven Web App</h2>
<a href="hello">Call HelloServlet</a>
</body>
</html>
