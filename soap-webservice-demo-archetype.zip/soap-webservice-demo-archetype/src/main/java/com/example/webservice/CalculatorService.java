package com.example.webservice;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService
public interface CalculatorService {

    @WebMethod
    int add(@WebParam(name = "num1") int num1,
            @WebParam(name = "num2") int num2);

    @WebMethod
    int subtract(@WebParam(name = "num1") int num1,
                 @WebParam(name = "num2") int num2);

    @WebMethod
    int multiply(@WebParam(name = "num1") int num1,
                 @WebParam(name = "num2") int num2);

    @WebMethod
    double divide(@WebParam(name = "num1") int num1,
                  @WebParam(name = "num2") int num2);
}