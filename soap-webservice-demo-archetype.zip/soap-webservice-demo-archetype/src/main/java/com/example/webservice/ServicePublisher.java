package com.example.webservice;

import javax.xml.ws.Endpoint;

public class ServicePublisher {
    public static void main(String[] args) {
        String url = "http://localhost:9090/calculator";

        System.out.println("Publishing Calculator Service at: " + url);
        Endpoint.publish(url, new CalculatorServiceImpl());
        System.out.println("Service is running...");
        System.out.println("WSDL available at: " + url + "?wsdl");
    }
}