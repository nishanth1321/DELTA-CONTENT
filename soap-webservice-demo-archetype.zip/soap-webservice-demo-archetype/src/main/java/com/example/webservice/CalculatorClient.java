package com.example.webservice;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.net.URL;

public class CalculatorClient {
    public static void main(String[] args) throws Exception {
        // WSDL URL
        URL wsdlUrl = new URL("http://localhost:9090/calculator?wsdl");

        // Service QName
        QName qname = new QName(
                "http://webservice.example.com/",
                "CalculatorServiceImplService"
        );

        // Create service
        Service service = Service.create(wsdlUrl, qname);

        // Get port
        CalculatorService calculator = service.getPort(CalculatorService.class);

        // Call methods
        System.out.println("10 + 5 = " + calculator.add(10, 5));
        System.out.println("10 - 5 = " + calculator.subtract(10, 5));
        System.out.println("10 * 5 = " + calculator.multiply(10, 5));
        System.out.println("10 / 5 = " + calculator.divide(10, 5));
    }
}