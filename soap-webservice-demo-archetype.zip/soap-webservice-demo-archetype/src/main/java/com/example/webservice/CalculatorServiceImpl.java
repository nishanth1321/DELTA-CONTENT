package com.example.webservice;

import javax.jws.WebService;

@WebService(endpointInterface = "com.example.webservice.CalculatorService")
public class CalculatorServiceImpl implements CalculatorService {

    @Override
    public int add(int num1, int num2) {
        System.out.println("Adding: " + num1 + " + " + num2);
        return num1 + num2;
    }

    @Override
    public int subtract(int num1, int num2) {
        System.out.println("Subtracting: " + num1 + " - " + num2);
        return num1 - num2;
    }

    @Override
    public int multiply(int num1, int num2) {
        System.out.println("Multiplying: " + num1 + " * " + num2);
        return num1 * num2;
    }

    @Override
    public double divide(int num1, int num2) {
        if (num2 == 0) {
            throw new IllegalArgumentException("Cannot divide by zero");
        }
        System.out.println("Dividing: " + num1 + " / " + num2);
        return (double) num1 / num2;
    }
}